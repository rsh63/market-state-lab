# Market State Lab — launch package

## Brand decision

**Recommended name:** Market State Lab  
**Daily product:** Quant Market Brief  
**Future paid product:** Quant Lab  
**Tagline:** Signals, regimes, and execution for systematic market decisions.

“The Predictive Edge” remains useful positioning language but is not the publication name. A 2024 Wiley book already uses that exact title in the AI-and-markets niche, creating avoidable search and brand confusion.

## Positioning

Market State Lab is for readers who want a decision-ready market state—not another headline feed. Each daily issue contains exactly five developments, an evidence-based regime label, execution and options risks, factor context, MATLAB/DRL implementation notes, and one falsifiable quant question.

The differentiator is not prediction theater. It is disciplined compression:

1. Facts are separated from inference.
2. Every time-sensitive number carries an as-of label.
3. Missing Level 2, options, or factor data is disclosed rather than estimated.
4. Technical ideas are paired with implementation and failure-mode notes.
5. A public GitHub companion preserves methods, sources, code, and corrections.

## Free-to-paid path

Launch with all daily briefs free. Do not enable paid subscriptions initially. After a consistent free publishing record and a meaningful engaged-reader base, add Quant Lab as a weekly paid research product. Each Quant Lab should contain a hypothesis, data contract, MATLAB notebook or function, purged walk-forward evaluation, transaction-cost model, sensitivity analysis, and explicit non-results.

## Launch assets

- Publication-ready inaugural issue: `issues/2026-08-11-inaugural.md`
- Substack configuration and About copy: `docs/channel-playbook.md`
- LinkedIn launch post and newsletter copy: `templates/linkedin-launch.md`
- GitHub README, methodology, disclosures, corrections policy, and MATLAB example
- Original masthead, avatar, social card, five story cards, and market dashboard
- 30-day editorial calendar and reusable daily/weekly templates

## First 30 days

- Publish the free brief on weekday mornings.
- Use LinkedIn to distribute a 60-second decision panel, not a duplicate wall of text.
- Link every issue to the GitHub companion.
- Record corrections visibly and timestamp data limitations.
- Track subscriber conversion, opens, completion proxy, saves, GitHub stars, and meaningful replies.
- Defer sponsorships, paid tiers, and trade calls until the editorial process has a public reliability record.

## Success criteria before Quant Lab becomes paid

- Four consecutive weeks of on-time free issues.
- A documented corrections process used consistently.
- At least two reproducible public MATLAB companions.
- Reader evidence that the technical depth is valued: saves, replies, GitHub engagement, or explicit research requests.
- A paid issue pipeline that can be sustained without reducing daily-brief quality.

This publication provides research and educational material only, not individualized financial advice.
