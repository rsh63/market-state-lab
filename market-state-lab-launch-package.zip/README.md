# Market State Lab

**Signals, regimes, and execution for systematic market decisions.**

Market State Lab is a free, premarket publication for quantitative traders, MATLAB users, and market practitioners. Its daily flagship, **Quant Market Brief**, compresses five important developments into a market-state view with explicit data quality, execution risk, model hygiene, and one testable research question.

The future paid product, **Quant Lab**, will be a weekly reproducible research note with code, walk-forward tests, cost assumptions, and a public change log. It is intentionally not enabled at launch.

## Start here

- [Inaugural Quant Market Brief](issues/2026-08-11-inaugural.md)
- [Methodology and source standards](docs/methodology.md)
- [Editorial and corrections policy](docs/editorial-policy.md)
- [Risk disclosure](docs/disclosures.md)
- [Brand guide](docs/brand-guide.md)
- [Channel launch playbook](docs/channel-playbook.md)
- [MATLAB market-state example](matlab/README.md)

## Publication architecture

| Product | Cadence | Access | Job to be done |
|---|---:|---|---|
| Quant Market Brief | Weekday premarket | Free | Five developments, regime map, execution risk, and one testable idea |
| Quant Lab | Weekly, later phase | Paid later | Reproducible MATLAB research, robustness tests, and implementation notes |
| GitHub companion | Per issue | Free | Sources, methods, code, revisions, and chart data |
| LinkedIn edition | Per issue | Free | Condensed decision panel and distribution |

## Repository map

```text
assets/      Brand and issue graphics
data/        Source-backed snapshots used in charts and tables
docs/        Methodology, editorial policy, disclosures, and launch playbook
issues/      Publication-ready issues
matlab/      Reproducible technical companions
templates/   Daily brief, Quant Lab, and social templates
```

## Data and licensing

Editorial content is © Market State Lab. All rights reserved unless otherwise stated. Code in `matlab/` is released under the MIT License. Third-party facts and data remain subject to their providers' terms. Source links and access dates are included in each issue.

This is research and education, not individualized financial advice. Markets involve risk, and models can fail.
