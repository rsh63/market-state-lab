# Quant Lab — research note template

## Question

State one falsifiable hypothesis and why it matters.

## Data contract

Universe, timestamps, survivorship treatment, corporate actions, source, revision policy, and missing-data rules.

## Method

Baseline, proposed feature or policy, cost model, constraints, and evaluation metrics.

## Walk-forward design

Training window, validation window, test window, purge/embargo, refit cadence, and untouched holdout.

## Results

Net and gross results, turnover, capacity proxy, drawdown, tail behavior, calibration, and regime slices.

## Robustness and non-results

Parameter sensitivity, alternative universes, randomized costs/latency, placebo tests, and what failed.

## MATLAB companion

Reproducible code, environment notes, random seeds, and expected outputs.

## Decision

Reject, retain for research, paper trade, or cautiously promote—with explicit criteria.
