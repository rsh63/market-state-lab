# First 30 days

## Week 1 — establish the contract

- Publish the inaugural brief and methodology.
- Pin the LinkedIn launch post.
- Publish the MATLAB market-state scoring companion.
- Invite corrections and research questions.

## Week 2 — prove repeatability

- Maintain the five-story constraint and data-status labels.
- Add one original chart to each issue.
- Publish a short GitHub note on options-quote hygiene.

## Week 3 — deepen technical value

- Publish a free mini-lab on cost-aware reward design.
- Show one negative or inconclusive result.
- Add a public research backlog through GitHub Issues.

## Week 4 — assess paid readiness

- Publish a monthly scorecard: cadence, corrections, reader engagement, and completed experiments.
- Survey readers on the most valuable Quant Lab format.
- Decide whether to announce a paid weekly waitlist; do not activate billing without a sustainable pipeline.
