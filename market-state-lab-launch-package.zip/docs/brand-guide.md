# Brand guide

## Identity

- **Name:** Market State Lab
- **Tagline:** Signals, regimes, and execution for systematic market decisions.
- **Daily:** Quant Market Brief
- **Weekly later:** Quant Lab
- **Editorial promise:** Five developments. One market state. One testable idea.

## Voice

Calm, precise, technically literate, and skeptical of false precision. Lead with the decision implication, then the evidence. Avoid hype, price targets, and unsupported superlatives.

Use these labels consistently:

- **Confirmed:** directly supported by a primary or high-quality source.
- **Inference:** an interpretation derived from stated facts.
- **Uncertainty:** a known data, timing, model, or source limitation.
- **Data status:** live, delayed, indicative, prior close, or latest verified snapshot.

## Visual system

- Ink navy: `#0B1F33`
- Signal cyan: `#18A6D9`
- Risk amber: `#F0A33B`
- Stress coral: `#E8675A`
- Paper: `#F5F7FA`
- Grid gray: `#AAB5C2`

Use a restrained grid, mono numerals, and generous white space. Original charts should replace decorative stock photos whenever a quantitative relationship is available.

## Naming notes

“The Predictive Edge” was not selected as the publication name because it overlaps with a 2024 Wiley title focused on AI and financial forecasting. It can appear only as ordinary positioning language, such as “build a predictive edge through better market-state discipline.”
