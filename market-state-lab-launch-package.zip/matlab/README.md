# MATLAB companion

`marketStateScore.m` demonstrates a transparent, vectorized market-state score using synchronized timetable inputs. It is an educational starting point, not a production signal.

```matlab
state = marketStateScore(features);
summary(state(:, {'Score','Regime','Confidence'}))
```

Expected variables are `EquityReturn`, `RateChangeBp`, `OilReturn`, `VolChange`, and `LiquidityZ`. Inputs should be point-in-time values with no forward filling across unavailable market sessions unless that rule is explicitly validated.

The function uses robust clipping and a simple rule-based confidence penalty for missing inputs. Replace fixed weights only through purged walk-forward evaluation, and keep the risk projector outside the learned policy.
